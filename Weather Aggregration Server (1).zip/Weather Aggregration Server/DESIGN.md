Design Sketch (updated)
=======================

What we built
-------------
Raw-socket, HTTP/1.1‑style weather aggregation system with end‑to‑end Lamport clocks, safe persistence, and robust error handling. Three runnable programs:

- AggregationServer: accepts `PUT /weather.json` from ContentServers and `GET /weather.json[?id=...]` from GETClients.
- ContentServer: reads a local key:value file, converts it to JSON, and PUTs it to the server.
- GETClient: fetches the current snapshot and prints friendly key:value lines.

Key guarantees
--------------
- Consistency via Lamport clocks: all PUTs are applied in Lamport order (ties broken by a nano‑time tiebreaker). GET waits until all ≤ its snapshot Lamport are applied.
- Crash safety: atomic file persistence; clean recovery on restart.
- Freshness bounds: stations expire after 30s of no updates; only the 20 most recently updated stations are retained.

High‑level architecture
-----------------------
1) AggregationServer (TCP)
   - Accept loop (cached thread pool) handles connections.
   - Each connection parses a small HTTP‑like request and routes to GET/PUT handlers.
   - PUTs are enqueued into a `PriorityBlockingQueue` ordered by `(lamport, tieBreaker)`.
   - A single applier thread takes from the queue and mutates state.
   - A scheduled task runs every 2s to expire stale stations (>30s).
   - State is saved atomically after each change.

2) ContentServer
   - Parses the station file with `JSONUtils` (rejects missing `id`, coerces numbers).
   - Sends a PUT with headers: `Content-Type`, `Content-Length`, `X-Lamport-Clock`.
   - Retries (bounded, exponential backoff) on connect/read timeout.

3) GETClient
   - Sends a GET with `X-Lamport-Clock`, reads `Content-Length` bodies or drains to EOF.
   - Retries (bounded, exponential backoff) on connect/read timeout.

Data model & synchronization
----------------------------
- `datastore`: `ConcurrentHashMap<String, JSONObject>` holds the latest JSON per station `id`.
- `heartbeats`: `ConcurrentHashMap<String, Long>` tracks last seen time per station.
- `last20`: bounded deque of most recent station ids, guarded by `last20Lock`.
- Lamport clock: `LamportClock` with `tick()` and `update(received)`.
- `appliedLamport`: highest Lamport that has been fully applied. `waitUntilApplied()` lets GET wait for consistency.

HTTP mapping (simplified)
-------------------------
- PUT /weather.json
  - Validates `Content-Length`. `0` or `<0` ⇒ `204 No Content`.
  - Parses JSON; missing/empty `id` or invalid JSON ⇒ `500`.
  - First/new‑after‑expiry ⇒ `201`; otherwise `200`.

- GET /weather.json[?id=...]
  - Builds `{ "stations": [...] }` snapshot, plus metadata (server time, lamport).
  - Unsupported method/path ⇒ `400`.

Persistence
-----------
- On each change, build a JSON snapshot: `{ stations: [...], lamport: <int> }`.
- Write to `store.json.tmp`, `force()`, then atomic‑move to `store.json` (fallback to replace if atomic move unsupported).
- On startup, load `store.json` only; bump Lamport to at least the saved value.

Expiry and MRU‑20
-----------------
- Every 2s, remove stations whose `lastSeen < now - 30_000`.
- `updateLast20()` maintains an MRU set; when size > 20, evict oldest not present anymore.

Threading & safety notes
------------------------
- Only the applier thread mutates `datastore`/`heartbeats`; GET reads directly (thread‑safe).
- `last20Lock` guards only the deque; no nested locks → no deadlocks.
- `applyCondLock` is used solely for GET to wait for `appliedLamport` to advance.

Error handling & robustness
---------------------------
- Status codes: 200/201/204/400/500 as above.
- Clients print clear error messages and retry on transient network failures.
- Server uses socket read timeouts to avoid indefinite blocking.

Testing strategy (implemented)
------------------------------
- Tests live in `src/*Test.java` and run via `TestRunner`:
  - `LamportClockTest`: tick/update rules; basic concurrent ticks.
  - `JSONAndClientsTest`: JSON parse/validate; GET client network failure.
  - `AggregationServerSuiteTest`: method/path validation; PUT statuses (201/200/204/500); GET all/by id; concurrent PUTs.
- Run with:

      javac -cp ".;out;lib/*" -d out src/*.java
      java  -cp ".;out;lib/*" TestRunner

Design trade‑offs
-----------------
- A single applier thread simplifies ordering and consistency. For assignment scales, throughput is sufficient.
- GET waits up to 2s for applied Lamport. This is a practical, simple bound; could be refined to wait on an enqueued barrier.

What to change if extending
---------------------------
- Strict snapshots: capture “max enqueued Lamport at GET start” and wait on that instead of a fixed timeout.
- Replicated servers: would require inter‑replica Lamport/consensus and state sync (not in scope here).


