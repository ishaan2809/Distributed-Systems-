import org.json.JSONObject;
import java.net.SocketTimeoutException;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

// Client that sends weather station data to the aggregation server
// Reads weather data from a file and sends it via HTTP PUT request
public class ContentServer {
    // Connection timeout in milliseconds
    private static final int TIMEOUT_MS = 10000;

    // Main method that sends weather data to the server
    // Usage: ContentServer <serverUrl> <stationFile>
    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Usage: ContentServer <serverUrl> <stationFile>");
            System.exit(2);
        }
        String serverUrl = args[0];
        String filePath = args[1];

        // Create Lamport clock for request ordering
        LamportClock clock = new LamportClock();

        try {
            // Parse the weather station file into JSON
            JSONObject json = JSONUtils.parseFileToJSON(filePath);
            
            // Parse server URL to extract host and port
            String host;
            int port;
            String[] parsed = parseHostPort(serverUrl);
            host = parsed[0];
            port = Integer.parseInt(parsed[1]);

            // Prepare the HTTP request body
            String body = json.toString();
            byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
            int sendLamport = clock.tick();

            // Connect to server and send the data with simple retries on failure
            int attempts = 0;
            int maxAttempts = 3;
            long backoffMs = 500;
            IOException lastIo = null;
            while (attempts < maxAttempts) {
                attempts++;
                try (Socket sock = new Socket()) {
                    sock.connect(new InetSocketAddress(host, port), TIMEOUT_MS);
                    sock.setSoTimeout(TIMEOUT_MS);

                    OutputStream out = sock.getOutputStream();
                    InputStream in = sock.getInputStream();

                    // Build HTTP PUT request with proper headers
                    String req =
                            "PUT /weather.json HTTP/1.1\r\n" +
                                    "Host: " + host + ":" + port + "\r\n" +
                                    "User-Agent: ATOMClient/1/0\r\n" +
                                    "Content-Type: application/json; charset=utf-8\r\n" +
                                    "Content-Length: " + bodyBytes.length + "\r\n" +
                                    "Connection: close\r\n" +
                                    "X-Lamport-Clock: " + sendLamport + "\r\n" +
                                    "\r\n";

                    // Send request and data
                    out.write(req.getBytes(StandardCharsets.US_ASCII));
                    out.write(bodyBytes);
                    out.flush();

                    // Read and display server response
                    BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.US_ASCII));
                    String status = br.readLine();
                    if (status == null) throw new IOException("No response");

                    // Skip response headers
                    String line;
                    while ((line = br.readLine()) != null && !line.isEmpty()) {
                        // Headers are ignored
                    }

                    // Read response body if present
                    StringBuilder sb = new StringBuilder();
                    while ((line = br.readLine()) != null) sb.append(line).append("\n");

                    System.out.println(status);
                    if (sb.length() > 0) System.out.println(sb.toString().trim());
                    lastIo = null;
                    break; // success
                } catch (SocketTimeoutException | java.net.ConnectException ioe) {
                    lastIo = ioe;
                    try { Thread.sleep(backoffMs); } catch (InterruptedException ignore) {}
                    backoffMs *= 2;
                }
            }
            if (lastIo != null) throw lastIo;

        } catch (SocketTimeoutException te) {
            System.err.println("PUT failed: Read timed out");
        } catch (Exception e) {
            System.err.println("PUT failed: " + e.getMessage());
        }
    }

    // Parses a URL string to extract host and port information
    // Handles both http:// and https:// prefixes and defaults to port 4567
    private static String[] parseHostPort(String url) {
        String u = url.trim();
        if (u.startsWith("http://")) u = u.substring(7);
        if (u.startsWith("https://")) u = u.substring(8);
        
        // Remove path portion if present
        int slash = u.indexOf('/');
        if (slash >= 0) u = u.substring(0, slash);
        
        String host;
        String port;
        int colon = u.lastIndexOf(':');
        if (colon >= 0) {
            host = u.substring(0, colon);
            port = u.substring(colon + 1);
        } else {
            host = u;
            port = "4567"; // Default port
        }
        return new String[]{host, port};
    }
}
