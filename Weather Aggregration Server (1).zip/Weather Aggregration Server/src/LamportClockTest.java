import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Lamport clock core logic and simple concurrency
public class LamportClockTest {
  @Test void tickIncrements() {
    LamportClock lc = new LamportClock();
    assertEquals(1, lc.tick());
    assertEquals(2, lc.tick());
  }

  @Test void updateFollowsMaxPlusOne() {
    LamportClock lc = new LamportClock();
    lc.tick();                   // 1
    assertEquals(6, lc.update(5));
    assertEquals(7, lc.tick());
    assertEquals(12, lc.update(11));
  }

  @Test void concurrentTicksAreSafe() throws Exception {
    LamportClock lc = new LamportClock();
    Thread t1 = new Thread(() -> { for (int i=0;i<100;i++) lc.tick(); });
    Thread t2 = new Thread(() -> { for (int i=0;i<100;i++) lc.tick(); });
    t1.start(); t2.start(); t1.join(); t2.join();
    assertEquals(200, lc.getTime());
  }
}
