import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

// Aggregation server functionality, failure modes, concurrency edge
public class AggregationServerSuiteTest {

  private static Process server;
  private static final int PORT = 4576;

  @BeforeAll
  static void up() throws Exception {
    server = new ProcessBuilder("java","-cp",".;out;lib/*","AggregationServer", String.valueOf(PORT))
            .redirectErrorStream(true).start();
    Thread.sleep(800);
  }

  @AfterAll
  static void down() { if (server != null) server.destroyForcibly(); }

  @Test void methodsPathsAndStatuses() throws Exception {
    // unsupported -> 400
    String r1 = raw("POST /weather.json HTTP/1.1\r\nHost: l\r\n\r\n");
    assertTrue(r1.startsWith("HTTP/1.1 400"));

    // empty body -> 204
    String r2 = raw("PUT /weather.json HTTP/1.1\r\nHost: l\r\nContent-Length: 0\r\n\r\n");
    assertTrue(r2.startsWith("HTTP/1.1 204"));

    // invalid JSON -> 500
    String r3 = raw("PUT /weather.json HTTP/1.1\r\nHost: l\r\nContent-Length: 5\r\n\r\nhello");
    assertTrue(r3.startsWith("HTTP/1.1 500"));

    // first good -> 201; update -> 200
    String j = new JSONObject().put("id","S1").put("v",1).toString();
    String p1 = put(j);
    assertTrue(p1.startsWith("HTTP/1.1 201") || p1.startsWith("HTTP/1.1 200"));
    String p2 = put(new JSONObject().put("id","S1").put("v",2).toString());
    assertTrue(p2.startsWith("HTTP/1.1 200"));
  }

  @Test void contentLengthMismatchReturns400() throws Exception {
    String resp = raw("PUT /weather.json HTTP/1.1\r\nHost: l\r\nContent-Length: 10\r\n\r\n{}\r\n");
    assertTrue(resp.startsWith("HTTP/1.1 400"));
  }

  @Test void getAllAndByIdAndLamport() throws Exception {
    String all = raw("GET /weather.json HTTP/1.1\r\nHost: l\r\n\r\n");
    String body = body(all);
    JSONArray arr = new JSONObject(body).optJSONArray("stations");
    assertNotNull(arr);

    String one = raw("GET /weather.json?id=S1 HTTP/1.1\r\nHost: l\r\n\r\n");
    String ob = body(one);
    JSONArray arr1 = new JSONObject(ob).getJSONArray("stations");
    assertNotNull(arr1);
  }

  @Test void concurrentPutsFromTwoClients() throws Exception {
    Thread a = new Thread(() -> safePut("C1", 10));
    Thread b = new Thread(() -> safePut("C2", 10));
    a.start(); b.start(); a.join(); b.join();

    String all = raw("GET /weather.json HTTP/1.1\r\nHost: l\r\n\r\n");
    String bd = body(all);
    JSONArray arr = new JSONObject(bd).getJSONArray("stations");
    boolean c1=false, c2=false;
    for (int i=0;i<arr.length();i++) {
      String id = arr.getJSONObject(i).optString("id");
      if ("C1".equals(id)) c1=true; if ("C2".equals(id)) c2=true;
    }
    assertTrue(c1 && c2);
  }

  private static void safePut(String id, int n) {
    for (int i=0;i<n;i++) {
      try { put(new JSONObject().put("id", id).put("seq", i).toString()); } catch (Exception ignore) {}
    }
  }

  private static String put(String json) throws Exception {
    byte[] b = json.getBytes(StandardCharsets.UTF_8);
    String req = "PUT /weather.json HTTP/1.1\r\nHost: l\r\nContent-Type: application/json\r\nContent-Length: "
            + b.length + "\r\nX-Lamport-Clock: 1\r\n\r\n" + json;
    return raw(req);
  }

  private static String body(String resp) {
    int i = resp.indexOf("\r\n\r\n");
    return i>=0?resp.substring(i+4):"";
  }

  private static String raw(String req) throws Exception {
    try (Socket s = new Socket("localhost", PORT)) {
      s.getOutputStream().write(req.getBytes(StandardCharsets.US_ASCII));
      s.getOutputStream().flush();
      // Signal end-of-stream so the server does not wait for more bytes
      try { s.shutdownOutput(); } catch (Exception ignore) {}
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      s.getInputStream().transferTo(bout);
      return bout.toString(StandardCharsets.US_ASCII);
    }
  }
}
