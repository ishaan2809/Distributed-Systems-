import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

// Main server class that handles weather data aggregation
// Provides HTTP endpoints for weather stations to send data and clients to retrieve it
// Uses Lamport clock for request ordering and handles concurrent requests safely
public class AggregationServer {

    // Default port number for the server
    private static final int DEFAULT_PORT = 4567;
    // Maximum number of pending connections in the queue
    private static final int SOCKET_BACKLOG = 64;
    // Timeout for socket operations in milliseconds
    private static final int IO_TIMEOUT_MS = 10000;

    // File paths for data persistence
    private static final Path STORE = Paths.get("store.json");
    private static final Path STORE_TMP = Paths.get("store.json.tmp");

    // Thread-safe map storing weather data for each station
    private final ConcurrentHashMap<String, JSONObject> datastore = new ConcurrentHashMap<>();
    // Tracks when each station was last seen for expiry purposes
    private final ConcurrentHashMap<String, Long> heartbeats = new ConcurrentHashMap<>();
    // Keeps track of the 20 most recently updated stations
    private final Deque<String> last20 = new ArrayDeque<>();
    // Lock for thread-safe access to last20 queue
    private final Object last20Lock = new Object();

    // Lamport clock for maintaining request order across distributed systems
    private final LamportClock clock = new LamportClock();

    // Inner class representing a PUT request task
    private static class PutTask {
        final int lamport; // Lamport clock value for ordering
        final String stationId; // ID of the weather station
        final JSONObject payload; // Weather data to store
        final CompletableFuture<Integer> statusFuture = new CompletableFuture<>(); // Future for response status
        final long tieBreaker; // Used to break ties when lamport values are equal

        PutTask(int lamport, String stationId, JSONObject payload, long tieBreaker) {
            this.lamport = lamport;
            this.stationId = stationId;
            this.payload = payload;
            this.tieBreaker = tieBreaker;
        }
    }

    // Priority queue for PUT requests ordered by Lamport clock then tie-breaker
    private final PriorityBlockingQueue<PutTask> putQueue = new PriorityBlockingQueue<>(
            128, Comparator.<PutTask>comparingInt(t -> t.lamport).thenComparingLong(t -> t.tieBreaker)
    );

    // Thread pool for handling incoming connections
    private final ExecutorService acceptPool = Executors.newCachedThreadPool();
    // Scheduled thread pool for background tasks like expiry
    private final ScheduledExecutorService sched = Executors.newScheduledThreadPool(2);

    // Tracks the highest Lamport clock value that has been fully processed
    private final AtomicInteger appliedLamport = new AtomicInteger(0);
    // Lock for coordinating between PUT worker and GET requests
    private final Object applyCondLock = new Object();

    // Port number this server listens on
    private final int port;

    // Constructor that sets the port number for the server
    public AggregationServer(int port) {
        this.port = port;
    }

    // Main entry point - parses command line arguments and starts the server
    public static void main(String[] args) throws Exception {
        int port = DEFAULT_PORT;
        if (args.length >= 1) {
            try { port = Integer.parseInt(args[0]); } catch (NumberFormatException ignore) {}
        }
        AggregationServer server = new AggregationServer(port);
        server.start();
    }

    // Starts the server by loading existing data and setting up background tasks
    private void start() throws Exception {
        loadStore(); // Load any existing weather data from disk

        // Start the PUT worker thread that processes weather data updates
        sched.execute(this::putWorkerLoop);

        // Schedule expiry task to run every 2 seconds to remove old data
        sched.scheduleAtFixedRate(this::expireStaleStations, 2, 2, TimeUnit.SECONDS);

        // Main server loop - accepts connections and handles them in separate threads
        try (ServerSocket ss = new ServerSocket(port, SOCKET_BACKLOG)) {
            System.out.println("AggregationServer listening on port " + port);
            while (true) {
                final Socket s = ss.accept();
                s.setSoTimeout(IO_TIMEOUT_MS);
                acceptPool.execute(() -> handleConnection(s));
            }
        }
    }

    // Background worker thread that processes PUT requests in Lamport clock order
    private void putWorkerLoop() {
        while (true) {
            try {
                PutTask task = putQueue.take(); // waits for next task
                applyPut(task);
            } catch (Throwable t) {
                t.printStackTrace(System.err);
            }
        }
    }

    // Applies a PUT request by storing the weather data and updating metadata
    private void applyPut(PutTask t) {
        try {
            String id = t.stationId;
            long now = System.currentTimeMillis();

            // Check if this is a new station or one that was previously expired
            boolean isNewOrRevived = false;
            Long lastBeat = heartbeats.get(id);
            if (lastBeat == null || (now - lastBeat) > 30_000L) {
                isNewOrRevived = true;
            }

            // Store the weather data and update heartbeat
            datastore.put(id, deepCopy(t.payload));
            heartbeats.put(id, now);
            updateLast20(id);

            persistStore(); // Save to disk atomically

            // Update the applied Lamport clock value
            appliedLamport.updateAndGet(prev -> Math.max(prev, t.lamport));
            synchronized (applyCondLock) {
                applyCondLock.notifyAll(); // Notify waiting GET requests
            }

            // Return 201 for new/revived stations, 200 for updates
            t.statusFuture.complete(isNewOrRevived ? 201 : 200);
        } catch (Throwable e) {
            t.statusFuture.complete(500); // Return error status
        }
    }

    // Updates the list of 20 most recently active stations
    private void updateLast20(String id) {
        synchronized (last20Lock) {
            // Move this station to the end (most recent)
            last20.remove(id);
            last20.addLast(id);
            // Keep only the 20 most recent stations
            while (last20.size() > 20) {
                String evict = last20.removeFirst();
                // Only remove from data store if not in the recent list
                if (!last20.contains(evict)) {
                    datastore.remove(evict);
                    heartbeats.remove(evict);
                }
            }
        }
    }

    // Removes stations that haven't been heard from in the last 30 seconds
    private void expireStaleStations() {
        long cutoff = System.currentTimeMillis() - 30_000L;
        boolean changed = false;
        for (Map.Entry<String, Long> e : heartbeats.entrySet()) {
            if (e.getValue() < cutoff) {
                String id = e.getKey();
                heartbeats.remove(id);
                datastore.remove(id);
                synchronized (last20Lock) { last20.remove(id); }
                changed = true;
            }
        }
        if (changed) {
            try { persistStore(); } catch (Exception ignored) {}
        }
    }

    // ---------- Connection handling ----------

    private void handleConnection(Socket s) {
        try (Socket sock = s;
             InputStream in = sock.getInputStream();
             OutputStream out = sock.getOutputStream()) {

            // Parse request
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.US_ASCII));
            String requestLine = reader.readLine();
            if (requestLine == null || requestLine.isEmpty()) {
                writeResponse(out, 400, "Bad Request", "Empty request");
                return;
            }
            String[] parts = requestLine.split(" ");
            if (parts.length < 3) {
                writeResponse(out, 400, "Bad Request", "Malformed request line");
                return;
            }
            String method = parts[0].trim();
            String rawPath = parts[1].trim();
            String httpVersion = parts[2].trim();

            Map<String, String> headers = new LinkedHashMap<>();
            String line;
            int contentLength = -1;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                int idx = line.indexOf(':');
                if (idx > 0) {
                    String h = line.substring(0, idx).trim();
                    String v = line.substring(idx + 1).trim();
                    headers.put(h.toLowerCase(Locale.ROOT), v);
                    if (h.equalsIgnoreCase("Content-Length")) {
                        try { contentLength = Integer.parseInt(v); } catch (NumberFormatException ignore) {}
                    }
                }
            }

            int recvLamport = parseIntHeader(headers.get("x-lamport-clock"), -1);
            if (recvLamport >= 0) clock.update(recvLamport);
            else clock.tick();

            if (!httpVersion.startsWith("HTTP/1.")) {
                writeResponse(out, 400, "Bad Request", "HTTP/1.x required");
                return;
            }

            if (method.equalsIgnoreCase("PUT") && rawPath.equals("/weather.json")) {
                handlePUT(out, headers, reader, contentLength);
            } else if (method.equalsIgnoreCase("GET") &&
                    (rawPath.equals("/weather.json") || rawPath.startsWith("/weather.json?"))) {
                handleGET(out, headers, rawPath);
            } else {
                writeResponse(out, 400, "Bad Request", "Only GET /weather.json and PUT /weather.json supported");
            }

        } catch (SocketTimeoutException ste) {
            // client read timeout
        } catch (IOException ioe) {
            // connection aborted
        } catch (Throwable t) {
            t.printStackTrace(System.err);
        }
    }

    private void handlePUT(OutputStream out, Map<String,String> headers,
                           BufferedReader reader, int contentLength) throws IOException {
        if (contentLength < 0) {
            writeResponse(out, 204, "No Content", "");
            return;
        }
        // If the body length is explicitly zero, there is no content to process
        // Return 204 to signal that the request was received with no body
        if (contentLength == 0) {
            writeResponse(out, 204, "No Content", "");
            return;
        }
        char[] buf = new char[contentLength];
        int read = 0;
        while (read < contentLength) {
            int r = reader.read(buf, read, contentLength - read);
            if (r < 0) break;
            read += r;
        }
        if (read != contentLength) {
            writeResponse(out, 400, "Bad Request", "Content-Length mismatch");
            return;
        }
        String body = new String(buf);
        JSONObject payload;
        try {
            payload = new JSONObject(body);
        } catch (Exception e) {
            writeResponse(out, 500, "Internal Server Error", "Invalid JSON");
            return;
        }
        String stationId = payload.optString("id", "").trim();
        if (stationId.isEmpty()) {
            writeResponse(out, 500, "Internal Server Error", "JSON missing 'id'");
            return;
        }

        int sendLamport = clock.tick();
        long tie = System.nanoTime();
        PutTask task = new PutTask(sendLamport, stationId, payload, tie);
        putQueue.add(task);

        // Wait (briefly) until this PUT is applied to maintain correct GET interleaving
        int status;
        try {
            // Up to 8 seconds; if something goes wrong, return 500
            status = task.statusFuture.get(8, TimeUnit.SECONDS);
        } catch (Exception e) {
            status = 500;
        }

        writeJsonResponse(out, status, status == 201 ? "Created" : (status == 200 ? "OK" : "Error"),
                new JSONObject().put("status", status).put("id", stationId),
                sendLamport);
    }

    private void handleGET(OutputStream out, Map<String,String> headers, String rawPath) throws IOException {
        Map<String,String> query = parseQuery(rawPath);
        String filterId = query.get("id"); // optional

        int snapshotClock = clock.tick();

        // Wait until all PUTs with lamport <= snapshotClock are applied
        waitUntilApplied(snapshotClock, 2000);

        JSONObject response = new JSONObject();
        if (filterId != null && !filterId.isEmpty()) {
            JSONObject one = datastore.get(filterId);
            if (one != null) {
                response.put("stations", new JSONArray().put(one));
            } else {
                response.put("stations", new JSONArray());
            }
        } else {
            JSONArray arr = new JSONArray();
            for (JSONObject v : datastore.values()) arr.put(v);
            response.put("stations", arr);
        }
        response.put("server_time", Instant.now().toString());
        response.put("lamport", appliedLamport.get());

        writeJsonResponse(out, 200, "OK", response, snapshotClock);
    }

    private void waitUntilApplied(int target, long timeoutMs) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        synchronized (applyCondLock) {
            while (appliedLamport.get() < target && System.currentTimeMillis() < deadline) {
                try { applyCondLock.wait(50); } catch (InterruptedException ignored) {}
            }
        }
    }

    // ---------- HTTP helpers ----------

    private void writeResponse(OutputStream out, int code, String msg, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String h = "HTTP/1.1 " + code + " " + msg + "\r\n" +
                "Content-Type: text/plain; charset=utf-8\r\n" +
                "Content-Length: " + b.length + "\r\n" +
                "Connection: close\r\n" +
                "X-Lamport-Clock: " + clock.getTime() + "\r\n" +
                "\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        out.write(b);
        out.flush();
    }

    private void writeJsonResponse(OutputStream out, int code, String msg, JSONObject json, int sendLamport) throws IOException {
        byte[] b = json.toString().getBytes(StandardCharsets.UTF_8);
        String h = "HTTP/1.1 " + code + " " + msg + "\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: " + b.length + "\r\n" +
                "Connection: close\r\n" +
                "X-Lamport-Clock: " + sendLamport + "\r\n" +
                "\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        out.write(b);
        out.flush();
    }

    private int parseIntHeader(String v, int def) {
        if (v == null) return def;
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return def; }
    }

    private Map<String,String> parseQuery(String rawPath) {
        Map<String,String> m = new HashMap<>();
        int q = rawPath.indexOf('?');
        if (q < 0) return m;
        String qs = rawPath.substring(q + 1);
        for (String part : qs.split("&")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                String k = urlDecode(part.substring(0, eq));
                String v = urlDecode(part.substring(eq + 1));
                m.put(k, v);
            }
        }
        return m;
    }

    private String urlDecode(String s) {
        try { return URLDecoder.decode(s, "UTF-8"); } catch (UnsupportedEncodingException e) { return s; }
    }

    // ---------- Persistence ----------

    private void loadStore() {
        // Ignore .tmp; only read stable file
        if (!Files.exists(STORE)) return;
        try {
            String text = Files.readString(STORE, StandardCharsets.UTF_8);
            if (text == null || text.isEmpty()) return;
            JSONObject root = new JSONObject(text);
            JSONArray arr = root.optJSONArray("stations");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String id = o.optString("id", "");
                    if (!id.isEmpty()) {
                        datastore.put(id, o);
                        heartbeats.put(id, System.currentTimeMillis()); // conservative: mark as seen now
                        updateLast20(id);
                    }
                }
            }
            int lam = root.optInt("lamport", 0);
            if (lam > 0) {
                // bump clock to be safe
                clock.update(lam);
                appliedLamport.set(lam);
            }
        } catch (Exception e) {
            System.err.println("Failed to load store.json, starting empty: " + e.getMessage());
        }
    }

    private void persistStore() throws IOException {
        JSONObject root = new JSONObject();
        JSONArray arr = new JSONArray();
        for (JSONObject v : datastore.values()) arr.put(v);
        root.put("stations", arr);
        root.put("lamport", appliedLamport.get());
        byte[] data = root.toString().getBytes(StandardCharsets.UTF_8);

        Files.write(STORE_TMP, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        try {
            Files.move(STORE_TMP, STORE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException amnse) {
            Files.move(STORE_TMP, STORE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static JSONObject deepCopy(JSONObject o) {
        return new JSONObject(o.toString()); // simple deep copy
    }
}
