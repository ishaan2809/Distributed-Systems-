import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

// Client that retrieves weather data from the aggregation server
// Can get all weather data or filter by specific station ID
public class GETClient {
    // Connection timeout in milliseconds
    private static final int TIMEOUT_MS = 10000;

    // Main method that retrieves weather data from the server
    // Usage: GETClient <serverUrl> [stationId]
    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("Usage: GETClient <serverUrl> [stationId]");
            System.exit(2);
        }
        String serverUrl = args[0];
        String filterId = args.length >= 2 ? args[1] : null; // Optional station ID filter

        // Create Lamport clock for request ordering
        LamportClock clock = new LamportClock();

        try {
            // Parse server URL to extract host and port
            String host;
            int port;
            String[] parsed = parseHostPort(serverUrl);
            host = parsed[0];
            port = Integer.parseInt(parsed[1]);

            // Build the request path with optional station ID filter
            String path = "/weather.json";
            if (filterId != null && !filterId.isEmpty()) {
                path += "?id=" + urlEncode(filterId);
            }
            int sendLamport = clock.tick();

            // Connect to server and send GET request with simple retries
            int attempts = 0;
            int maxAttempts = 3;
            long backoffMs = 500;
            IOException lastIo = null;
            while (attempts < maxAttempts) {
                attempts++;
                try (Socket sock = new Socket()) {
                    sock.connect(new InetSocketAddress(host, port), TIMEOUT_MS);
                    sock.setSoTimeout(TIMEOUT_MS);
                    OutputStream out = sock.getOutputStream();
                    InputStream in = sock.getInputStream();

                // Build HTTP GET request
                String req =
                        "GET " + path + " HTTP/1.1\r\n" +
                                "Host: " + host + ":" + port + "\r\n" +
                                "User-Agent: ATOMClient/1/0\r\n" +
                                "Connection: close\r\n" +
                                "X-Lamport-Clock: " + sendLamport + "\r\n" +
                                "\r\n";
                    out.write(req.getBytes(StandardCharsets.US_ASCII));
                    out.flush();

                // Read and parse server response
                    BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.US_ASCII));
                    String status = br.readLine();
                    if (status == null) throw new IOException("No response");
                
                // Parse response headers to get content length
                String line;
                int contentLength = -1;
                while ((line = br.readLine()) != null && !line.isEmpty()) {
                    int idx = line.indexOf(':');
                    if (idx > 0) {
                        String h = line.substring(0, idx).trim();
                        String v = line.substring(idx + 1).trim();
                        if (h.equalsIgnoreCase("Content-Length")) {
                            try { contentLength = Integer.parseInt(v); } catch (NumberFormatException ignore) {}
                        }
                    }
                }

                // Read response body
                    String body;
                    if (contentLength >= 0) {
                    // Read exact number of bytes specified by Content-Length
                    char[] buf = new char[contentLength];
                    int read = 0;
                    while (read < contentLength) {
                        int r = br.read(buf, read, contentLength - read);
                        if (r < 0) break;
                        read += r;
                    }
                        body = new String(buf, 0, read);
                    } else {
                    // Read until end of stream if no Content-Length
                    StringBuilder sb = new StringBuilder();
                    while ((line = br.readLine()) != null) sb.append(line).append("\n");
                        body = sb.toString();
                    }

                // Handle error responses
                    if (!status.contains("200")) {
                        System.out.println(status);
                        System.out.println(body.trim());
                        return;
                    }

                // Parse JSON response and display weather data
                    JSONObject json = new JSONObject(body);
                    JSONArray stations = json.optJSONArray("stations");
                    if (stations == null) stations = new JSONArray();

                // Print each station's data in key:value format
                    for (int i = 0; i < stations.length(); i++) {
                        JSONObject obj = stations.getJSONObject(i);
                        printFlatJSONObject(obj);
                        if (i < stations.length() - 1) System.out.println("----");
                    }
                    lastIo = null;
                    break; // success
                } catch (SocketTimeoutException | java.net.ConnectException ioe) {
                    lastIo = ioe;
                    try { Thread.sleep(backoffMs); } catch (InterruptedException ignore) {}
                    backoffMs *= 2;
                }
            }
            if (lastIo != null) throw lastIo;
        } catch (Exception e) {
            System.err.println("GET failed: " + e.getMessage());
        }
    }

    // Prints JSON object fields in key:value format with id field first
    private static void printFlatJSONObject(JSONObject obj) {
        // Print id field first for consistency
        if (obj.has("id")) System.out.println("id: " + obj.get("id"));
        
        // Print all other fields
        for (Iterator<String> it = obj.keys(); it.hasNext();) {
            String k = it.next();
            if ("id".equals(k)) continue; // Skip id since it was already printed
            System.out.println(k + ": " + obj.get(k));
        }
    }

    // Parses a URL string to extract host and port information
    // Handles both http:// and https:// prefixes and defaults to port 4567
    private static String[] parseHostPort(String url) {
        String u = url.trim();
        if (u.startsWith("http://")) u = u.substring(7);
        if (u.startsWith("https://")) u = u.substring(8);
        
        // Remove path portion if present
        int slash = u.indexOf('/');
        if (slash >= 0) u = u.substring(0, slash);
        
        String host;
        String port;
        int colon = u.lastIndexOf(':');
        if (colon >= 0) {
            host = u.substring(0, colon);
            port = u.substring(colon + 1);
        } else {
            host = u;
            port = "4567"; // Default port
        }
        return new String[]{host, port};
    }

    // URL encodes a string for use in query parameters
    private static String urlEncode(String s) throws UnsupportedEncodingException {
        return java.net.URLEncoder.encode(s, "UTF-8");
    }
}
