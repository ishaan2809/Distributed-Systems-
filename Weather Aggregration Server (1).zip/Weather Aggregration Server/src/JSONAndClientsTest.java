import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.json.JSONObject;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.*;

// JSON parsing and basic client failure modes
public class JSONAndClientsTest {

  @TempDir static Path tmp;

  @Test void jsonUtilsParsesAndValidates() throws Exception {
    Path f = tmp.resolve("ok.txt");
    Files.writeString(f, "id: X\nint:42\nfloat:3.5\n");
    var j = JSONUtils.parseFileToJSON(f.toString());
    assertEquals("X", j.getString("id"));
    assertEquals(42L, j.getLong("int"));
    assertEquals(3.5, j.getDouble("float"));
  }

  @Test void jsonUtilsRejectsMissingId() throws Exception {
    Path f = tmp.resolve("bad.txt");
    Files.writeString(f, "name:N\n");
    assertThrows(Exception.class, () -> JSONUtils.parseFileToJSON(f.toString()));
  }

  @Test void getClientReportsServerDown() throws Exception {
    Process p = new ProcessBuilder("java","-cp",".;out;lib/*","GETClient","http://localhost:4998").start();
    String err = new String(p.getErrorStream().readAllBytes());
    p.waitFor();
    assertTrue(err.contains("GET failed") || err.contains("Connection refused") || err.contains("getsockopt"));
  }

  @Test void contentServerReportsFileError() throws Exception {
    Process p = new ProcessBuilder("java","-cp",".;out;lib/*","ContentServer","http://localhost:4998","nonexistent.txt").start();
    String out = new String(p.getErrorStream().readAllBytes());
    p.waitFor();
    assertTrue(out.contains("PUT failed"));
  }
}
