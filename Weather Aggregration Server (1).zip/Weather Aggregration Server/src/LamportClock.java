// Lamport clock implementation for maintaining logical time ordering
// Used to ensure requests are processed in the correct order across distributed systems
public class LamportClock {
    private int time; // Current logical time value

    // Initialize clock to 0
    public LamportClock() { this.time = 0; }

    // Increment the clock and return the new value
    // Used when sending a message or performing a local event
    public synchronized int tick() {
        time++;
        return time;
    }

    // Update clock based on received message timestamp
    // Sets clock to max(current time, received time) + 1
    public synchronized int update(int receivedTime) {
        time = Math.max(time, receivedTime) + 1;
        return time;
    }

    // Get the current logical time value
    public synchronized int getTime() { return time; }
}
