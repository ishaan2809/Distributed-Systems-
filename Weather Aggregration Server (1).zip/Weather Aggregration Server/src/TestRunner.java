import org.junit.platform.console.ConsoleLauncher;

// Runs all tests with verbose output
public class TestRunner {
    public static void main(String[] args) {
        ConsoleLauncher.main(new String[] {
                "--select-class=LamportClockTest",
                "--select-class=JSONAndClientsTest",
                "--select-class=AggregationServerSuiteTest",
                "--details=verbose"
        });
    }
}


