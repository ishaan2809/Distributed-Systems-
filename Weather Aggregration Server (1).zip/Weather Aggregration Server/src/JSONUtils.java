import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

// Utility class for parsing weather station files and converting them to JSON
public class JSONUtils {
    
    // Parses a key:value format file into a JSON object
    // Throws IOException if the file cannot be read or if required 'id' field is missing
    public static JSONObject parseFileToJSON(String filePath) throws IOException {
        Map<String, String> map = new HashMap<>();
        
        // Read the file line by line
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue; // Skip empty lines
                
                // Split on first colon to separate key and value
                int idx = line.indexOf(':');
                if (idx <= 0) continue; // Skip lines without colon
                
                String key = line.substring(0, idx).trim();
                String value = line.substring(idx + 1).trim();
                map.put(key, value);
            }
        }
        
        // Validate that required 'id' field is present and not empty
        if (!map.containsKey("id") || map.get("id").isEmpty())
            throw new IOException("Missing required field: id");

        // Convert map to JSON object with automatic type conversion
        JSONObject json = new JSONObject();
        for (Map.Entry<String, String> e : map.entrySet()) {
            String k = e.getKey();
            String v = e.getValue();
            
            // Try to convert numeric strings to appropriate number types
            if (v.matches("^-?\\d+(\\.\\d+)?$")) {
                try {
                    if (v.contains(".")) 
                        json.put(k, Double.parseDouble(v)); // Decimal number
                    else 
                        json.put(k, Long.parseLong(v)); // Integer number
                } catch (NumberFormatException nfe) {
                    json.put(k, v); // Keep as string if parsing fails
                }
            } else {
                json.put(k, v); // Keep as string for non-numeric values
            }
        }
        return json;
    }
}
